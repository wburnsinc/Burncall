import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { businessesTable } from "./businesses";

/**
 * We store extracted TEXT only, not the original file bytes — there's no
 * object storage (S3/R2) configured in this stack, and for the purpose of
 * training the AI receptionist, the text content is all that's actually
 * needed. If you want the original file preservable/downloadable later,
 * that's a real but separate feature (needs an object storage service).
 */
export const documentsTable = pgTable("documents", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id),
  filename: text("filename").notNull(),
  mimeType: text("mime_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  chunkCount: integer("chunk_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/**
 * Chunked text used for retrieval. Retrieval uses Postgres full-text search
 * (to_tsvector/plainto_tsquery + ts_rank) rather than vector embeddings —
 * this keeps the feature fully self-contained with zero external API keys.
 * It's lexical/keyword-based, not semantic — a real, working, honest
 * trade-off. Swapping in true embeddings (e.g. Voyage AI, which Anthropic
 * recommends) is a reasonable future upgrade if search quality needs to
 * improve, but requires a separate API key.
 */
export const documentChunksTable = pgTable("document_chunks", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull().references(() => documentsTable.id),
  businessId: integer("business_id").notNull().references(() => businessesTable.id),
  chunkIndex: integer("chunk_index").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Document = typeof documentsTable.$inferSelect;
export type DocumentChunk = typeof documentChunksTable.$inferSelect;
