import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import { eq } from "drizzle-orm";
import { db, documentsTable, documentChunksTable } from "@workspace/db";
import { requireAuth, requireRole } from "../middlewares/requireAuth";
import { extractText, chunkText } from "../lib/documentParser";
import { logger } from "../lib/logger";

const router: IRouter = Router();
router.use(requireAuth);

// In-memory storage — files are parsed for text immediately and never
// written to disk, since there's no persistent file storage in this stack.
// 10MB cap keeps things reasonable without needing a storage quota system.
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// GET /api/documents
router.get("/documents", async (req: Request, res: Response) => {
  const docs = await db.select().from(documentsTable).where(eq(documentsTable.businessId, req.auth!.businessId));
  res.json({ documents: docs, total: docs.length });
});

// POST /api/documents — upload + parse + chunk. Same permission tier as
// Knowledge Base editing (owner/admin/dispatcher, not technician).
router.post("/documents", requireRole("owner", "admin", "dispatcher"), upload.single("file"), async (req: Request, res: Response) => {
  const file = req.file;
  if (!file) {
    res.status(400).json({ error: "No file uploaded (expected multipart field 'file')" });
    return;
  }

  try {
    const text = await extractText(file.buffer, file.mimetype, file.originalname);
    const chunks = chunkText(text);

    if (chunks.length === 0) {
      res.status(400).json({ error: "No extractable text found in this file." });
      return;
    }

    const [doc] = await db
      .insert(documentsTable)
      .values({ businessId: req.auth!.businessId, filename: file.originalname, mimeType: file.mimetype, sizeBytes: file.size, chunkCount: chunks.length })
      .returning();

    await db.insert(documentChunksTable).values(
      chunks.map((content, i) => ({ documentId: doc.id, businessId: req.auth!.businessId, chunkIndex: i, content })),
    );

    res.status(201).json(doc);
  } catch (err) {
    logger.error({ err }, "Document upload/parse failed");
    const message = err instanceof Error ? err.message : "Failed to process document";
    res.status(400).json({ error: message });
  }
});

// DELETE /api/documents/:id
router.delete("/documents/:id", requireRole("owner", "admin", "dispatcher"), async (req: Request, res: Response) => {
  const doc = await db.query.documentsTable.findFirst({ where: eq(documentsTable.id, Number(req.params.id)) });
  if (!doc || doc.businessId !== req.auth!.businessId) {
    res.status(404).json({ error: "Document not found" });
    return;
  }
  await db.delete(documentChunksTable).where(eq(documentChunksTable.documentId, doc.id));
  await db.delete(documentsTable).where(eq(documentsTable.id, doc.id));
  res.json({ success: true });
});

export default router;
