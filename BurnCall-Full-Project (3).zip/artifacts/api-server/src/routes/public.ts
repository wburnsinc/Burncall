import { Router, type IRouter, type Request, type Response } from "express";
import { eq } from "drizzle-orm";
import { db, appointmentsTable, businessesTable } from "@workspace/db";
import { buildAppointmentIcs, appointmentIcsToken } from "../lib/ics";

// Intentionally unauthenticated routes — meant to be opened directly from an
// emailed/texted link by a customer who has no BurnCall account. Since
// appointment IDs are sequential integers, the REAL access control here is
// the signed `t` token (appointmentIcsToken), not the id itself — without
// it, appointment ids could be enumerated to read other businesses' customer data.
const router: IRouter = Router();

// GET /api/appointments/:id/ics?t=<token> — real "add to calendar" file (Google/Apple/Outlook compatible)
router.get("/appointments/:id/ics", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const token = String(req.query.t || "");

  if (!token || token !== appointmentIcsToken(id)) {
    res.status(403).json({ error: "Invalid or missing access token" });
    return;
  }

  const appt = await db.query.appointmentsTable.findFirst({ where: eq(appointmentsTable.id, id) });
  if (!appt) {
    res.status(404).json({ error: "Appointment not found" });
    return;
  }
  const business = await db.query.businessesTable.findFirst({ where: eq(businessesTable.id, appt.businessId) });
  const ics = buildAppointmentIcs({
    uid: String(appt.id),
    businessName: business?.name || "Your service appointment",
    service: appt.service,
    customerName: appt.customerName,
    scheduledAt: new Date(appt.scheduledAt),
    durationMinutes: appt.duration ?? 60,
    address: appt.address,
  });
  res.set("Content-Type", "text/calendar; charset=utf-8");
  res.set("Content-Disposition", `attachment; filename="appointment-${appt.id}.ics"`);
  res.send(ics);
});

export default router;
