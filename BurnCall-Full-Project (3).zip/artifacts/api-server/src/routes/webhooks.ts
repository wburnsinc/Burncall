import { Router, type IRouter, type Request, type Response } from "express";
import crypto from "crypto";
import { eq } from "drizzle-orm";
import { db, webhooksTable, WEBHOOK_EVENT_TYPES } from "@workspace/db";
import { requireAuth, requireRole } from "../middlewares/requireAuth";

const router: IRouter = Router();
router.use(requireAuth);

/**
 * Basic SSRF guard: since our server will later fetch() whatever URL is
 * registered here (whenever a webhook event fires), block obviously
 * internal/private hosts. This is NOT complete protection — a fully robust
 * guard would also resolve DNS and check the resolved IP against private
 * ranges (blocking DNS-rebinding attacks), which is a reasonable next
 * hardening step if this matters for your threat model. This at least
 * blocks the common, obvious cases.
 */
function isBlockedWebhookHost(url: URL): boolean {
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host === "0.0.0.0" || host === "127.0.0.1" || host === "::1") return true;
  if (host === "169.254.169.254") return true; // cloud metadata endpoint (AWS/GCP/Azure)
  if (/^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(host)) return true; // 172.16.0.0/12
  if (url.protocol !== "http:" && url.protocol !== "https:") return true;
  return false;
}

// GET /api/webhooks
router.get("/webhooks", async (req: Request, res: Response) => {
  const hooks = await db.select().from(webhooksTable).where(eq(webhooksTable.businessId, req.auth!.businessId));
  res.json({ webhooks: hooks, availableEvents: WEBHOOK_EVENT_TYPES });
});

// POST /api/webhooks — register a new outbound webhook (owner/admin only)
router.post("/webhooks", requireRole("owner", "admin"), async (req: Request, res: Response) => {
  const { url, events } = req.body ?? {};
  if (!url || !Array.isArray(events) || events.length === 0) {
    res.status(400).json({ error: "url and a non-empty events array are required" });
    return;
  }
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    res.status(400).json({ error: "url must be a valid absolute URL" });
    return;
  }
  if (isBlockedWebhookHost(parsed)) {
    res.status(400).json({ error: "This URL points to an internal/private address and can't be used for webhooks." });
    return;
  }
  const invalid = events.filter((e: string) => !WEBHOOK_EVENT_TYPES.includes(e as any));
  if (invalid.length > 0) {
    res.status(400).json({ error: `Unknown event types: ${invalid.join(", ")}` });
    return;
  }

  const secret = crypto.randomBytes(24).toString("hex");
  const [hook] = await db.insert(webhooksTable).values({ businessId: req.auth!.businessId, url, events, secret, enabled: true }).returning();
  res.status(201).json(hook);
});

// PATCH /api/webhooks/:id — toggle enabled / change subscribed events
router.patch("/webhooks/:id", requireRole("owner", "admin"), async (req: Request, res: Response) => {
  const hook = await db.query.webhooksTable.findFirst({ where: eq(webhooksTable.id, Number(req.params.id)) });
  if (!hook || hook.businessId !== req.auth!.businessId) {
    res.status(404).json({ error: "Webhook not found" });
    return;
  }
  const { url, events, enabled } = req.body ?? {};
  const updates: Record<string, unknown> = {};
  if (url) {
    try {
      const parsed = new URL(url);
      if (isBlockedWebhookHost(parsed)) {
        res.status(400).json({ error: "This URL points to an internal/private address and can't be used for webhooks." });
        return;
      }
      updates.url = url;
    } catch {
      res.status(400).json({ error: "url must be a valid absolute URL" });
      return;
    }
  }
  if (events) updates.events = events;
  if (typeof enabled === "boolean") updates.enabled = enabled;

  const [updated] = await db.update(webhooksTable).set(updates).where(eq(webhooksTable.id, hook.id)).returning();
  res.json(updated);
});

// DELETE /api/webhooks/:id
router.delete("/webhooks/:id", requireRole("owner", "admin"), async (req: Request, res: Response) => {
  const hook = await db.query.webhooksTable.findFirst({ where: eq(webhooksTable.id, Number(req.params.id)) });
  if (!hook || hook.businessId !== req.auth!.businessId) {
    res.status(404).json({ error: "Webhook not found" });
    return;
  }
  await db.delete(webhooksTable).where(eq(webhooksTable.id, hook.id));
  res.json({ success: true });
});

export default router;
