/**
 * Generates a standards-compliant .ics (iCalendar) file for a single
 * appointment. This is a real, self-contained "add to calendar" capability
 * that works with Google Calendar, Apple Calendar, Outlook, etc. via the
 * universal .ics format — it does NOT require OAuth or a live integration
 * with any specific calendar provider (that would be a separate, larger
 * feature — see DEPLOY.md for why that's out of scope here).
 */

import crypto from "crypto";

/**
 * The .ics download route (GET /api/appointments/:id/ics) is intentionally
 * public/unauthenticated — a customer opens it from an emailed link without
 * logging in. But appointment IDs are sequential integers, so without this
 * token, anyone could enumerate /api/appointments/1/ics, /2/ics, etc. and
 * read OTHER businesses' customer names, addresses, and appointment times.
 * This HMAC token (derived from SESSION_SECRET, never exposed) is the actual
 * access control — only someone with the real emailed/generated link can
 * read a given appointment's calendar file.
 */
export function appointmentIcsToken(appointmentId: number): string {
  const secret = process.env.SESSION_SECRET || process.env.JWT_SECRET || "dev-only-insecure-secret-change-me";
  return crypto.createHmac("sha256", secret).update(`ics:${appointmentId}`).digest("hex").slice(0, 32);
}

function toIcsDate(date: Date): string {
  return date.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
}

function escapeIcsText(text: string): string {
  return text.replace(/[\\;,]/g, (m) => `\\${m}`).replace(/\n/g, "\\n");
}

export function buildAppointmentIcs(opts: {
  uid: string;
  businessName: string;
  service: string;
  customerName: string;
  scheduledAt: Date;
  durationMinutes: number;
  address?: string | null;
}): string {
  const start = opts.scheduledAt;
  const end = new Date(start.getTime() + opts.durationMinutes * 60000);

  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//BurnCall//Appointment//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${opts.uid}@burncall`,
    `DTSTAMP:${toIcsDate(new Date())}`,
    `DTSTART:${toIcsDate(start)}`,
    `DTEND:${toIcsDate(end)}`,
    `SUMMARY:${escapeIcsText(`${opts.service} — ${opts.businessName}`)}`,
    `DESCRIPTION:${escapeIcsText(`Appointment with ${opts.businessName} for ${opts.customerName}`)}`,
    opts.address ? `LOCATION:${escapeIcsText(opts.address)}` : null,
    "STATUS:CONFIRMED",
    "END:VEVENT",
    "END:VCALENDAR",
  ].filter(Boolean);

  return lines.join("\r\n");
}
