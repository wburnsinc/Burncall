import { sql, eq } from "drizzle-orm";
import { db, documentsTable } from "@workspace/db";

export async function hasDocuments(businessId: number): Promise<boolean> {
  const [row] = await db.select({ id: documentsTable.id }).from(documentsTable).where(eq(documentsTable.businessId, businessId)).limit(1);
  return Boolean(row);
}

export interface SearchResult {
  documentId: number;
  filename: string;
  content: string;
  rank: number;
}

/**
 * Keyword/lexical search over a business's uploaded document chunks using
 * Postgres's built-in full-text search (to_tsvector + plainto_tsquery +
 * ts_rank). This is real, working retrieval — just not semantic/embedding-
 * based. It handles word-stem matching (e.g. "cancel" matches "cancellation")
 * but won't catch pure paraphrases the way vector embeddings would.
 */
export async function searchDocuments(businessId: number, query: string, limit = 4): Promise<SearchResult[]> {
  if (!query.trim()) return [];

  const result = await db.execute(sql`
    SELECT dc.document_id AS "documentId", d.filename, dc.content,
           ts_rank(to_tsvector('english', dc.content), plainto_tsquery('english', ${query})) AS rank
    FROM document_chunks dc
    JOIN documents d ON d.id = dc.document_id
    WHERE dc.business_id = ${businessId}
      AND to_tsvector('english', dc.content) @@ plainto_tsquery('english', ${query})
    ORDER BY rank DESC
    LIMIT ${limit}
  `);

  return (result.rows as unknown as SearchResult[]) ?? [];
}
