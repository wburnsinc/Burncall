/**
 * Extracts plain text from an uploaded file buffer. Supports .txt, .pdf,
 * and .docx — the common formats a home service business would actually
 * upload (price sheets, service agreements, FAQ docs, policy PDFs).
 *
 * pdf-parse and mammoth are added to package.json but not installed in this
 * sandbox (no network access here) — they'll install normally via `pnpm i`
 * wherever this is actually deployed, same as every other real SDK in this
 * project (Anthropic, Stripe, Twilio, Resend).
 */
export async function extractText(buffer: Buffer, mimeType: string, filename: string): Promise<string> {
  const lower = filename.toLowerCase();

  if (mimeType === "text/plain" || lower.endsWith(".txt") || lower.endsWith(".md")) {
    return buffer.toString("utf-8");
  }

  if (mimeType === "application/pdf" || lower.endsWith(".pdf")) {
    const pdfParse = (await import("pdf-parse")).default;
    const result = await pdfParse(buffer);
    return result.text;
  }

  if (
    mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    lower.endsWith(".docx")
  ) {
    const mammoth = await import("mammoth");
    const result = await mammoth.extractRawText({ buffer });
    return result.value;
  }

  throw new Error(`Unsupported file type: ${mimeType || filename}. Supported: .txt, .md, .pdf, .docx`);
}

/**
 * Splits text into overlapping chunks for retrieval. Overlap helps avoid
 * losing context at chunk boundaries (e.g. a sentence split mid-thought).
 */
export function chunkText(text: string, chunkSize = 1000, overlap = 150): string[] {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) return [];

  const chunks: string[] = [];
  let start = 0;
  while (start < cleaned.length) {
    const end = Math.min(start + chunkSize, cleaned.length);
    chunks.push(cleaned.slice(start, end));
    if (end === cleaned.length) break;
    start = end - overlap;
  }
  return chunks;
}
