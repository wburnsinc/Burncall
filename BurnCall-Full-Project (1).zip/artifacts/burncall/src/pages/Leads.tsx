import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Download, LayoutGrid, List, Phone, Mail, MessageSquare, Star } from "lucide-react";
import { api } from "@/lib/api";

interface ApiLead {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  channel: string;
  source: string;
  service: string | null;
  score: number;
  status: string;
  estimatedValue: number | null;
  createdAt: string;
}

const STATUS_LABELS: Record<string, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  booked: "Appointment Booked",
  won: "Won",
  lost: "Lost",
};

const STATUS_COLORS: Record<string, string> = {
  "New": "bg-blue-500/20 text-blue-400 border-blue-500/30",
  "Contacted": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  "Qualified": "bg-orange-500/20 text-orange-400 border-orange-500/30",
  "Appointment Booked": "bg-purple-500/20 text-purple-400 border-purple-500/30",
  "Won": "bg-green-500/20 text-green-400 border-green-500/30",
  "Lost": "bg-slate-500/20 text-slate-400 border-slate-500/30",
};

const SCORE_COLOR = (s: number) => (s >= 80 ? "text-green-400" : s >= 50 ? "text-yellow-400" : "text-red-400");
const SCORE_LABEL = (s: number) => (s >= 80 ? "Hot" : s >= 50 ? "Warm" : "Low");

function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs === 1 ? "" : "s"} ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export default function Leads() {
  const [leads, setLeads] = useState<ApiLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [view, setView] = useState<"table" | "kanban">("table");
  const [selected, setSelected] = useState<number[]>([]);

  useEffect(() => {
    api
      .get<{ leads: ApiLead[] }>("/api/leads?limit=100")
      .then((data) => setLeads(data.leads))
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load leads"))
      .finally(() => setLoading(false));
  }, []);

  const statuses = ["All", "New", "Contacted", "Qualified", "Appointment Booked", "Won", "Lost"];

  const filtered = leads.filter((l) => {
    const label = STATUS_LABELS[l.status] || l.status;
    const matchesStatus = statusFilter === "All" || label === statusFilter;
    const q = search.toLowerCase();
    const matchesSearch = l.name.toLowerCase().includes(q) || (l.service || "").toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  const toggleSelect = (id: number) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const exportCsv = () => {
    const header = ["Name", "Contact", "Service", "Source", "Score", "Status", "Value", "Created"];
    const rows = filtered.map((l) => [l.name, l.phone || l.email || "", l.service || "", l.source, l.score, STATUS_LABELS[l.status] || l.status, l.estimatedValue ?? "", l.createdAt]);
    const csv = [header, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "leads.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div className="text-slate-400 text-sm p-6">Loading leads…</div>;
  if (error) return <div className="text-red-400 text-sm p-6">Couldn't load leads: {error}</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Leads</h1>
          <p className="text-slate-400 text-sm mt-0.5">{leads.length} total leads</p>
        </div>
        <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white" onClick={exportCsv} data-testid="export-csv">
          <Download className="h-4 w-4 mr-2" /> Export CSV
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-5">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search leads..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-slate-500"
            data-testid="search-leads"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {statuses.map((s) => (
            <button
              key={s}
              data-testid={`filter-${s.toLowerCase().replace(/\s+/g, "-")}`}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${statusFilter === s ? "bg-[#FF6B2B] text-white" : "bg-white/5 text-slate-400 hover:text-white border border-white/10"}`}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-lg p-1 ml-auto">
          <button onClick={() => setView("table")} className={`p-1.5 rounded ${view === "table" ? "bg-white/10 text-white" : "text-slate-400"}`} data-testid="view-table"><List className="h-4 w-4" /></button>
          <button onClick={() => setView("kanban")} className={`p-1.5 rounded ${view === "kanban" ? "bg-white/10 text-white" : "text-slate-400"}`} data-testid="view-kanban"><LayoutGrid className="h-4 w-4" /></button>
        </div>
      </div>

      {selected.length > 0 && (
        <div className="mb-4 flex items-center gap-3 p-3 bg-[#FF6B2B]/10 border border-[#FF6B2B]/20 rounded-xl">
          <span className="text-sm text-orange-400 font-medium">{selected.length} selected</span>
          <button className="ml-auto text-slate-400 text-xs" onClick={() => setSelected([])}>Clear</button>
        </div>
      )}

      {view === "table" ? (
        <div className="bg-[#0A0F1E] border border-white/10 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-xs uppercase tracking-wider">
                <th className="p-4 text-left w-8"><input type="checkbox" className="rounded border-white/20 bg-white/5" onChange={(e) => setSelected(e.target.checked ? filtered.map((l) => l.id) : [])} /></th>
                <th className="p-4 text-left">Name</th>
                <th className="p-4 text-left hidden md:table-cell">Service</th>
                <th className="p-4 text-left hidden lg:table-cell">Source</th>
                <th className="p-4 text-left">Score</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left hidden md:table-cell">Est. Value</th>
                <th className="p-4 text-left hidden lg:table-cell">Time</th>
                <th className="p-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((lead) => {
                const label = STATUS_LABELS[lead.status] || lead.status;
                return (
                  <tr key={lead.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                    <td className="p-4"><input type="checkbox" checked={selected.includes(lead.id)} onChange={() => toggleSelect(lead.id)} className="rounded border-white/20 bg-white/5" /></td>
                    <td className="p-4">
                      <div>
                        <Link href={`/leads/${lead.id}`} className="font-medium text-white hover:text-[#FF6B2B] transition-colors">{lead.name}</Link>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          {lead.channel === "sms" && <MessageSquare className="h-3 w-3 text-slate-500" />}
                          {lead.channel === "call" && <Phone className="h-3 w-3 text-slate-500" />}
                          {lead.channel === "web" && <Mail className="h-3 w-3 text-slate-500" />}
                          <span className="text-xs text-slate-500">{lead.phone || lead.email || "—"}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 hidden md:table-cell text-slate-300">{lead.service || "—"}</td>
                    <td className="p-4 hidden lg:table-cell text-slate-400 text-xs">{lead.source}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-1.5">
                        <Star className={`h-3 w-3 ${SCORE_COLOR(lead.score)}`} />
                        <span className={`font-semibold ${SCORE_COLOR(lead.score)}`}>{lead.score}</span>
                        <span className="text-slate-600 text-xs">{SCORE_LABEL(lead.score)}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge className={`text-xs border ${STATUS_COLORS[label] || "bg-slate-500/20 text-slate-400 border-slate-500/30"}`}>{label}</Badge>
                    </td>
                    <td className="p-4 hidden md:table-cell text-green-400 font-medium">{lead.estimatedValue ? `$${lead.estimatedValue.toLocaleString()}` : "—"}</td>
                    <td className="p-4 hidden lg:table-cell text-slate-500 text-xs">{timeAgo(lead.createdAt)}</td>
                    <td className="p-4">
                      <Link href={`/leads/${lead.id}`}>
                        <Button size="sm" variant="outline" className="border-white/20 text-white text-xs h-7 hover:bg-white/10">View</Button>
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-16 text-slate-500">
              <Search className="h-8 w-8 mx-auto mb-3 opacity-40" />
              <p>No leads match your search</p>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 overflow-x-auto">
          {["New", "Contacted", "Qualified", "Appointment Booked", "Won", "Lost"].map((status) => {
            const colLeads = leads.filter((l) => (STATUS_LABELS[l.status] || l.status) === status);
            return (
              <div key={status} className="min-w-[180px]">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{status}</span>
                  <span className="text-xs text-slate-600">{colLeads.length}</span>
                </div>
                <div className="space-y-2">
                  {colLeads.map((lead) => (
                    <Link key={lead.id} href={`/leads/${lead.id}`}>
                      <div className="bg-[#0A0F1E] border border-white/10 rounded-xl p-3 hover:border-[#FF6B2B]/40 transition-colors cursor-pointer">
                        <p className="text-white text-xs font-semibold mb-0.5">{lead.name}</p>
                        <p className="text-slate-400 text-xs mb-2">{lead.service || "—"}</p>
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-bold ${SCORE_COLOR(lead.score)}`}>{lead.score}</span>
                          <span className="text-green-400 text-xs">{lead.estimatedValue ? `$${lead.estimatedValue.toLocaleString()}` : "—"}</span>
                        </div>
                        <p className="text-slate-600 text-xs mt-1">{timeAgo(lead.createdAt)}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
