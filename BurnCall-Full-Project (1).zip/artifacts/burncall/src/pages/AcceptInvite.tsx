import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2 } from "lucide-react";
import logoPath from "@assets/bestlogo_1782311057091.png";
import { api, ApiError, setToken } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

export default function AcceptInvite() {
  const { refresh } = useAuth();
  const [, navigate] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const token = params.get("token") || "";

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!token) { setError("This invite link is missing its token — ask whoever invited you to resend it."); return; }
    if (password.length < 8) { setError("Password must be at least 8 characters."); return; }
    if (password !== confirm) { setError("Passwords don't match."); return; }

    setLoading(true);
    try {
      const data = await api.post<{ token: string; redirectTo: string }>("/api/auth/accept-invite", { token, password });
      setToken(data.token);
      await refresh();
      navigate(data.redirectTo || "/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong accepting this invite.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050812] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <img src={logoPath} alt="BurnCall" className="h-8 mx-auto mb-6" />
          <h1 className="text-xl font-bold text-white mb-1">Set up your account</h1>
          <p className="text-slate-400 text-sm">Choose a password to finish joining your team on BurnCall.</p>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-xs text-slate-400 mb-1.5 block">Password</label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-white/5 border-white/10 text-white h-11" data-testid="invite-password" />
          </div>
          <div>
            <label className="text-xs text-slate-400 mb-1.5 block">Confirm Password</label>
            <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="bg-white/5 border-white/10 text-white h-11" data-testid="invite-password-confirm" />
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <Button type="submit" disabled={loading} className="w-full bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white h-11" data-testid="accept-invite-submit">
            {loading ? "Setting up…" : <><CheckCircle2 className="h-4 w-4 mr-2" /> Accept Invite & Log In</>}
          </Button>
        </form>
      </div>
    </div>
  );
}
