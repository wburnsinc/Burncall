import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock, User, Bot, Phone, Calendar, DollarSign, ArrowRight, Star } from "lucide-react";

const steps = [
  {
    id: 1,
    label: "Lead Arrives",
    icon: Phone,
    description: "A homeowner submits a request on your website",
    content: (
      <div className="space-y-4">
        <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-10 w-10 rounded-full bg-slate-600 flex items-center justify-center text-white font-bold">S</div>
            <div>
              <p className="font-semibold text-white">Sarah Mitchell</p>
              <p className="text-xs text-slate-400">Website Form • Just now</p>
            </div>
            <Badge className="ml-auto bg-orange-500/20 text-orange-400 border-orange-500/30">New Lead</Badge>
          </div>
          <div className="bg-white/5 rounded-lg p-4 border border-white/5">
            <p className="text-slate-200 text-sm">"Hi, my AC is blowing warm air. Can someone come today? It's really hot in here."</p>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3 text-xs">
            <div className="bg-white/5 rounded-lg p-3 text-center">
              <p className="text-slate-400">Source</p>
              <p className="text-white font-medium mt-1">Website Form</p>
            </div>
            <div className="bg-white/5 rounded-lg p-3 text-center">
              <p className="text-slate-400">Service</p>
              <p className="text-white font-medium mt-1">HVAC Repair</p>
            </div>
            <div className="bg-white/5 rounded-lg p-3 text-center">
              <p className="text-slate-400">Urgency</p>
              <p className="text-orange-400 font-medium mt-1">Same Day</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 2,
    label: "AI Responds",
    icon: Bot,
    description: "BurnCall AI replies in under 60 seconds — personalized and professional",
    content: (
      <div className="space-y-4">
        <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-6">
          <div className="flex items-center gap-2 mb-5">
            <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse"></div>
            <span className="text-sm text-green-400 font-medium">AI responded in 14 seconds</span>
          </div>
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="h-8 w-8 rounded-full bg-slate-600 flex items-center justify-center text-white text-xs font-bold shrink-0 mt-1">S</div>
              <div className="bg-white/5 rounded-2xl rounded-tl-sm p-4 max-w-xs">
                <p className="text-sm text-slate-200">Hi, my AC is blowing warm air. Can someone come today?</p>
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <div className="bg-[#FF6B2B] rounded-2xl rounded-tr-sm p-4 max-w-xs">
                <p className="text-sm text-white">Hi Sarah — sorry you're dealing with that! We can definitely help. Is the system completely off, or is it running but blowing warm air?</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-[#FF6B2B]/30 flex items-center justify-center shrink-0 mt-1">
                <Bot className="h-4 w-4 text-[#FF6B2B]" />
              </div>
            </div>
          </div>
          <div className="mt-5 border-t border-white/5 pt-4">
            <p className="text-xs text-slate-500 text-center">BurnCall AI — responding on your behalf, 24/7</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 3,
    label: "AI Qualifies",
    icon: Star,
    description: "Smart qualification questions filter and score the lead automatically",
    content: (
      <div className="space-y-4">
        <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-6">
          <div className="space-y-3">
            {[
              { from: "Sarah", msg: "It's running but blowing warm air.", side: "left" },
              { from: "AI", msg: "Got it. What's your ZIP code so I can confirm we serve your area?", side: "right" },
              { from: "Sarah", msg: "32789", side: "left" },
              { from: "AI", msg: "We cover your area! Are you the homeowner or a tenant?", side: "right" },
              { from: "Sarah", msg: "Homeowner.", side: "left" },
              { from: "AI", msg: "Perfect. Would this afternoon between 1–5 PM work?", side: "right" },
              { from: "Sarah", msg: "Yes, that works!", side: "left" },
            ].map((m, i) => (
              <div key={i} className={`flex gap-2 ${m.side === "right" ? "justify-end" : ""}`}>
                {m.side === "left" && <div className="h-6 w-6 rounded-full bg-slate-600 flex items-center justify-center text-white text-xs font-bold shrink-0 mt-1">S</div>}
                <div className={`rounded-2xl p-3 max-w-[220px] text-xs ${m.side === "right" ? "bg-[#FF6B2B] text-white rounded-tr-sm" : "bg-white/5 text-slate-200 rounded-tl-sm"}`}>
                  {m.msg}
                </div>
                {m.side === "right" && <div className="h-6 w-6 rounded-full bg-[#FF6B2B]/30 flex items-center justify-center shrink-0 mt-1"><Bot className="h-3 w-3 text-[#FF6B2B]" /></div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 4,
    label: "Lead Scored",
    icon: Star,
    description: "AI scores the lead based on 10 qualification signals",
    content: (
      <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-6 space-y-4">
        <div className="flex items-center gap-4">
          <div className="h-20 w-20 rounded-full border-4 border-green-400 flex items-center justify-center">
            <span className="text-2xl font-bold text-white">92</span>
          </div>
          <div>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-sm mb-1">HOT LEAD</Badge>
            <p className="text-white font-semibold">Sarah M. — AC Repair</p>
            <p className="text-slate-400 text-xs mt-1">Score: 92 / 100</p>
          </div>
        </div>
        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 text-sm text-green-300">
          High score because: in your service area, emergency urgency, confirmed homeowner, same-day availability, and complete contact info.
        </div>
        <div className="space-y-2">
          {[
            { label: "Service Area Match", score: true },
            { label: "Homeowner Confirmed", score: true },
            { label: "Same-Day Urgency", score: true },
            { label: "Appointment Available", score: true },
            { label: "Contact Complete", score: true },
            { label: "Spam Check", score: true },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between text-xs">
              <span className="text-slate-400">{item.label}</span>
              <CheckCircle2 className="h-4 w-4 text-green-400" />
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 5,
    label: "Appointment Booked",
    icon: Calendar,
    description: "Booking link sent — Sarah picks a time instantly",
    content: (
      <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-6 space-y-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-full bg-[#FF6B2B]/20 flex items-center justify-center">
            <Bot className="h-5 w-5 text-[#FF6B2B]" />
          </div>
          <div>
            <p className="text-sm text-white font-medium">BurnCall AI sent booking link</p>
            <p className="text-xs text-slate-400">Just now</p>
          </div>
        </div>
        <div className="bg-white/5 rounded-xl p-5 border border-white/10">
          <p className="text-white font-semibold mb-1">Appointment Confirmed</p>
          <p className="text-slate-400 text-sm mb-4">Sarah picked a slot from your calendar</p>
          <div className="space-y-3 text-sm">
            <div className="flex gap-3">
              <Calendar className="h-4 w-4 text-[#FF6B2B] mt-0.5 shrink-0" />
              <div>
                <p className="text-white">Tuesday, May 20, 2025</p>
                <p className="text-slate-400 text-xs">2:00 PM – 4:00 PM</p>
              </div>
            </div>
            <div className="flex gap-3">
              <User className="h-4 w-4 text-[#FF6B2B] mt-0.5 shrink-0" />
              <div>
                <p className="text-white">Sarah Mitchell</p>
                <p className="text-slate-400 text-xs">sarah.m@email.com • (407) 555-0192</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-xs text-blue-300">
          SMS + Email confirmation sent to Sarah automatically
        </div>
      </div>
    ),
  },
  {
    id: 6,
    label: "Owner Notified",
    icon: Phone,
    description: "You get an instant alert with full lead details",
    content: (
      <div className="space-y-3">
        <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Phone className="h-4 w-4 text-[#FF6B2B]" />
            <span className="text-sm font-semibold text-white">Push Notification</span>
          </div>
          <div className="bg-slate-800 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-lg bg-[#FF6B2B] flex items-center justify-center text-xs font-bold text-white">BC</div>
              <div>
                <p className="text-white text-xs font-semibold">BurnCall</p>
                <p className="text-slate-400 text-xs">Now</p>
              </div>
            </div>
            <p className="text-white text-sm font-medium">New appointment booked</p>
            <p className="text-slate-300 text-xs mt-1">Sarah M. — AC Repair — Tue May 20 @ 2:00 PM — Est. $1,250</p>
          </div>
        </div>
        <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-5">
          <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider">Also notified</p>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-slate-300"><CheckCircle2 className="h-4 w-4 text-green-400" /> SMS to owner: +1 (407) 555-0100</div>
            <div className="flex items-center gap-2 text-slate-300"><CheckCircle2 className="h-4 w-4 text-green-400" /> Email digest sent</div>
            <div className="flex items-center gap-2 text-slate-300"><CheckCircle2 className="h-4 w-4 text-green-400" /> Added to Google Calendar</div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 7,
    label: "Revenue Rescued",
    icon: DollarSign,
    description: "Dashboard updates — job revenue tracked automatically",
    content: (
      <div className="bg-[#0A0F1E] rounded-xl border border-white/10 p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: "Revenue Rescued Today", value: "$5,600", color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" },
            { label: "This Month", value: "$18,640", color: "text-[#FF6B2B]", bg: "bg-orange-500/10 border-orange-500/20" },
            { label: "Jobs Booked Today", value: "4", color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
            { label: "Est. Sarah's Job", value: "$1,250", color: "text-white", bg: "bg-white/5 border-white/10" },
          ].map((stat) => (
            <div key={stat.label} className={`rounded-xl border p-4 ${stat.bg}`}>
              <p className="text-xs text-slate-400 mb-1">{stat.label}</p>
              <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
            </div>
          ))}
        </div>
        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 text-center">
          <p className="text-green-400 font-semibold text-lg">Sarah M. lead: RESCUED</p>
          <p className="text-slate-400 text-sm mt-1">From missed call to booked job in 4 minutes 32 seconds</p>
        </div>
      </div>
    ),
  },
];

export default function Demo() {
  const [currentStep, setCurrentStep] = useState(0);

  return (
    <div className="bg-[#050812] min-h-screen text-white">
      <div className="container mx-auto px-4 py-20 max-w-5xl">
        <div className="text-center mb-14">
          <Badge className="mb-4 bg-orange-500/20 text-orange-400 border-orange-500/30">Interactive Demo</Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">See BurnCall in action</h1>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">Walk through a real inbound lead — from first contact to booked job — in under 5 minutes.</p>
        </div>

        <div className="grid md:grid-cols-[280px_1fr] gap-8">
          <div className="space-y-2">
            {steps.map((step, i) => {
              const Icon = step.icon;
              const done = i < currentStep;
              const active = i === currentStep;
              return (
                <button
                  key={step.id}
                  data-testid={`demo-step-${step.id}`}
                  onClick={() => setCurrentStep(i)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${active ? "bg-[#FF6B2B]/20 border border-[#FF6B2B]/40" : done ? "bg-white/5 border border-white/10" : "border border-transparent hover:bg-white/5"}`}
                >
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${active ? "bg-[#FF6B2B]" : done ? "bg-green-500" : "bg-white/10"}`}>
                    {done ? <CheckCircle2 className="h-4 w-4 text-white" /> : <span className="text-xs font-bold text-white">{step.id}</span>}
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${active ? "text-[#FF6B2B]" : done ? "text-green-400" : "text-slate-300"}`}>{step.label}</p>
                    <p className="text-xs text-slate-500 leading-tight mt-0.5">{step.description}</p>
                  </div>
                </button>
              );
            })}
          </div>

          <div>
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Step {currentStep + 1} of {steps.length}</p>
                <h2 className="text-xl font-bold text-white">{steps[currentStep].label}</h2>
                <p className="text-slate-400 text-sm">{steps[currentStep].description}</p>
              </div>
              <div className="flex gap-2">
                {currentStep > 0 && (
                  <Button variant="outline" size="sm" className="border-white/20 text-white" onClick={() => setCurrentStep(s => s - 1)}>
                    Back
                  </Button>
                )}
                {currentStep < steps.length - 1 ? (
                  <Button size="sm" className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white" onClick={() => setCurrentStep(s => s + 1)} data-testid="demo-next">
                    Next Step <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                ) : (
                  <Link href="/signup">
                    <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                      Start Free Trial <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                  </Link>
                )}
              </div>
            </div>

            <div className="w-full bg-white/5 rounded-full h-1.5 mb-6">
              <div className="bg-[#FF6B2B] h-1.5 rounded-full transition-all" style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }} />
            </div>

            {steps[currentStep].content}
          </div>
        </div>

        <div className="mt-20 text-center border-t border-white/10 pt-14">
          <h3 className="text-2xl font-bold mb-3">Ready to rescue your leads?</h3>
          <p className="text-slate-400 mb-6">Start your 14-day free trial. No credit card required.</p>
          <Link href="/signup">
            <Button size="lg" className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white px-10 h-13">
              Start Free Trial
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
