import React, { useState } from "react";
import { Link } from "wouter";
import logoPath from "@assets/bestlogo_1782311057091.png";
import { Button } from "@/components/ui/button";
import { Facebook, Twitter, Linkedin, Instagram, Menu, X } from "lucide-react";

export default function MarketingLayout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground dark">
      <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#0A0F1E]/95 backdrop-blur supports-[backdrop-filter]:bg-[#0A0F1E]/80">
        <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <img src={logoPath} alt="BurnCall Logo" className="h-8 w-auto" />
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex gap-6">
            <Link href="/how-it-works" className="text-sm font-medium text-white/80 hover:text-white transition-colors">Product</Link>
            <Link href="/pricing" className="text-sm font-medium text-white/80 hover:text-white transition-colors">Pricing</Link>
            <Link href="/industries" className="text-sm font-medium text-white/80 hover:text-white transition-colors">Industries</Link>
            <Link href="/about" className="text-sm font-medium text-white/80 hover:text-white transition-colors">About</Link>
            <Link href="/demo" className="text-sm font-medium text-white/80 hover:text-white transition-colors">Demo</Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link href="/login" className="text-sm font-medium text-white/80 hover:text-white transition-colors hidden md:block">
              Log in
            </Link>
            <Link href="/signup">
              <Button className="bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white border-none font-semibold hidden sm:inline-flex">
                Start Free Trial
              </Button>
            </Link>
            {/* Mobile menu toggle */}
            <button
              className="md:hidden text-white/80 hover:text-white"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-white/10 bg-[#0A0F1E] px-4 pb-4 pt-3 space-y-1">
            {[
              { href: "/how-it-works", label: "Product" },
              { href: "/pricing", label: "Pricing" },
              { href: "/industries", label: "Industries" },
              { href: "/about", label: "About" },
              { href: "/demo", label: "Interactive Demo" },
              { href: "/login", label: "Log In" },
            ].map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="block py-2 text-sm text-white/80 hover:text-white transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <Link href="/signup" onClick={() => setMobileOpen(false)}>
              <Button className="w-full mt-2 bg-[#FF6B2B] hover:bg-[#FF6B2B]/90 text-white font-semibold">
                Start Free Trial
              </Button>
            </Link>
          </div>
        )}
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-white/10 bg-[#0A0F1E] py-12 text-white/70">
        <div className="container mx-auto px-4 md:px-6 grid gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <img src={logoPath} alt="BurnCall Logo" className="h-8 w-auto opacity-90" />
            <p className="text-sm max-w-xs">
              Turn missed calls into booked jobs. BurnCall's AI assistant answers every lead inquiry 24/7.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-5 w-5 hover:text-white cursor-pointer" />
              <Twitter className="h-5 w-5 hover:text-white cursor-pointer" />
              <Linkedin className="h-5 w-5 hover:text-white cursor-pointer" />
              <Instagram className="h-5 w-5 hover:text-white cursor-pointer" />
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-4">Product</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/how-it-works" className="hover:text-white">How it Works</Link></li>
              <li><Link href="/pricing" className="hover:text-white">Pricing</Link></li>
              <li><Link href="/demo" className="hover:text-white">Interactive Demo</Link></li>
              <li><Link href="/industries" className="hover:text-white">Industries</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/about" className="hover:text-white">About BurnCall</Link></li>
              <li><Link href="/signup" className="hover:text-white">Get Started</Link></li>
              <li><Link href="/demo" className="hover:text-white">Request Demo</Link></li>
              <li><Link href="/login" className="hover:text-white">Sign In</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/privacy" className="hover:text-white">Privacy Policy</Link></li>
              <li><Link href="/terms" className="hover:text-white">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto px-4 md:px-6 mt-12 pt-8 border-t border-white/10 text-sm flex flex-col md:flex-row justify-between items-center gap-3">
          <p>© {new Date().getFullYear()} BurnCall Inc. All rights reserved.</p>
          <p className="text-slate-600 text-xs">AI lead response and booking platform for home-service businesses.</p>
        </div>
      </footer>
    </div>
  );
}
