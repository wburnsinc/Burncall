import { pgTable, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { businessesTable } from "./businesses";

export const aiUsageLogTable = pgTable("ai_usage_log", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id),
  inputTokens: integer("input_tokens").notNull(),
  outputTokens: integer("output_tokens").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type AiUsageLog = typeof aiUsageLogTable.$inferSelect;
