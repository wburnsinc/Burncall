import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { automationsTable } from "./automations";

export const automationRunsTable = pgTable("automation_runs", {
  id: serial("id").primaryKey(),
  automationId: integer("automation_id").notNull().references(() => automationsTable.id),
  targetType: text("target_type").notNull(), // lead | appointment
  targetId: integer("target_id").notNull(),
  ranAt: timestamp("ran_at").notNull().defaultNow(),
});

export type AutomationRun = typeof automationRunsTable.$inferSelect;
