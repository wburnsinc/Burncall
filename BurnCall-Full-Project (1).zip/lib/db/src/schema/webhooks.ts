import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { businessesTable } from "./businesses";

export const webhooksTable = pgTable("webhooks", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id),
  url: text("url").notNull(),
  events: jsonb("events").$type<string[]>().notNull().default([]), // e.g. ["lead.created","lead.qualified","appointment.confirmed"]
  secret: text("secret").notNull(), // used to sign delivery payloads (HMAC-SHA256)
  enabled: boolean("enabled").notNull().default(true),
  lastDeliveryAt: timestamp("last_delivery_at"),
  lastStatus: text("last_status"), // "ok" | "failed" | null (never delivered)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertWebhookSchema = createInsertSchema(webhooksTable).omit({ id: true, createdAt: true });
export type InsertWebhook = z.infer<typeof insertWebhookSchema>;
export type Webhook = typeof webhooksTable.$inferSelect;

export const WEBHOOK_EVENT_TYPES = [
  "lead.created",
  "lead.qualified",
  "lead.won",
  "lead.lost",
  "appointment.confirmed",
  "appointment.cancelled",
] as const;
