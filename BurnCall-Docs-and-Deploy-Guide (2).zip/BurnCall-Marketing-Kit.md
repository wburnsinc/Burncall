# BurnCall Marketing Kit

*Landing page copy + feature comparison sheet, built strictly from what's actually implemented in the current build. Nothing below claims a feature that doesn't work today.*

---

## 1. Landing Page Copy

### Hero Section

**Headline:**
Every Missed Lead Is Money Left On The Table

**Subheadline:**
BurnCall's AI receptionist answers your website chats and texts the moment they come in — qualifies the customer, answers their questions using your real pricing and policies, and books the appointment. No more leads going cold while you're on a job.

**Primary CTA:** Start Free Trial
**Secondary CTA:** See a Live Demo

---

### Problem Section

**Headline:** You Can't Answer The Phone When You're Under a Sink

For home service businesses, the first company to respond usually wins the job. But when you're mid-job, after hours, or slammed with calls, leads sit unanswered — and go to a competitor who picked up first.

---

### Solution Section

**Headline:** An AI Receptionist That Actually Knows Your Business

BurnCall isn't a generic chatbot. You train it on your real services, pricing, FAQs, and rules — then it handles conversations exactly the way you would.

**Feature blocks:**

**🤖 Responds Instantly, On Every Channel**
Your AI receptionist answers website chat messages and inbound text messages automatically, using your actual services and FAQs — not a generic script.

**📋 Qualifies Every Lead**
The AI asks the right follow-up questions, figures out urgency and service type, and scores each lead so your team knows who to call back first.

**📅 Books Real Appointments**
When a customer is ready to schedule, the AI checks your actual calendar of booked jobs and locks in a time — no back-and-forth required.

**🚨 Knows When to Get You Involved**
Emergencies, angry customers, or questions outside what you've trained it on get escalated to your team immediately by email, instead of the AI guessing.

**📊 A Real Dashboard, Not Vanity Metrics**
Track lead volume, response times, and booked revenue — calculated from your actual leads and appointments, not sample data.

**🎛️ You're in Control of What It Says**
Edit your services, FAQs, and custom AI instructions any time, and the AI's behavior updates immediately — including a safe "test it yourself" tool before it ever talks to a real customer.

---

### How It Works

1. **Set up your business** — services, pricing, service area, FAQs, tone
2. **Connect your channels** — add BurnCall's chat to your website, forward your business texts
3. **Go live** — the AI starts responding immediately, day or night
4. **Review and take over anytime** — every conversation is visible in your inbox, and you can jump in and reply personally whenever you want

---

### Pricing Section

*(Use your existing Starter / Growth / Pro tiers — copy already reflects your current plan structure. Trial messaging below is accurate to what's built.)*

**14-day free trial. No credit card required to start.**

---

### Trust / Honesty Footnote (recommended, not required)

*BurnCall is actively adding integrations. Calendar sync, CRM connections, and team permissions are on our roadmap — see our [feature list] for what's live today.*

*(This line is optional, but recommended if you're marketing to a technical or skeptical B2B audience — it builds credibility rather than risking a "why doesn't this work" support ticket.)*

---

## 2. Feature Comparison Sheet

Use this internally, in sales calls, or in an FAQ/support doc. Columns reflect the current build exactly.

### ✅ Fully Working Today

| Feature | What It Actually Does |
|---|---|
| AI Receptionist (Web Chat) | Real Claude-powered responses using your services/FAQs; requires your Anthropic API key |
| AI Receptionist (SMS) | Same AI, triggered by inbound text via Twilio; requires a Twilio number |
| Lead Qualification | AI extracts service, urgency, ZIP, and estimated value automatically |
| Lead Scoring & Pipeline | Real Kanban/table view of leads by status (New → Contacted → Qualified → Booked → Won) |
| Appointment Booking | AI checks real booked slots and books directly into your calendar of appointments |
| Manual Appointment Management | Create, reschedule, cancel appointments yourself |
| Team Inbox | See every AI conversation; take over and reply as a human — replies send via real SMS/email |
| Email Notifications | Real delivery via Resend when configured |
| SMS Notifications | Real delivery via Twilio when configured |
| Escalation to Humans | AI flags emergencies/unknowns and emails your team automatically |
| Dashboard Analytics | Lead volume, response time, revenue — computed from your real data |
| Knowledge Base Editing | Services, FAQs, and custom AI instructions — changes affect the AI immediately |
| AI Response Testing | Preview how the AI will respond without creating a fake lead |
| Account & Billing | Real signup/login, real Stripe subscription checkout and status tracking |
| Team Roster | Add team members to your account roster, with a real invite email sent |

### ⚠️ Built, But Limited — Be Careful How You Market These

| Feature | The Honest Limitation |
|---|---|
| Automations | You can create and enable follow-up automation rules, but nothing currently triggers them to fire automatically (e.g., "text a lead after 24 hours of silence" doesn't yet run on its own) |
| Team Invites | Invited team members are added to your roster and get a notification email, but there's no login/account-creation flow for them yet — they can't actually sign in |
| Role Permissions | Owner/Admin/Dispatcher/Technician roles exist in the UI as a reference, but aren't enforced — any logged-in user currently has full access |
| Calendar Link | You can add a Calendly/Google Calendar link for the AI to share, but there's no live two-way calendar sync |

### ❌ Not Built — Do Not Market These

| Feature | Status |
|---|---|
| Google Calendar / Calendly sync | Not built |
| CRM integrations (HubSpot, etc.) | Not built |
| Field service integrations (ServiceTitan, Jobber, Housecall Pro) | Not built |
| Zapier / 6,000+ app integrations | Not built |
| Gmail / Outlook inbox monitoring | Not built |
| Document upload / AI training on PDFs | Not built |
| Webhooks for custom developer integrations | Not built |

---

## 3. Suggested Safe Marketing Language

**Use:**
- "AI-powered lead response and appointment booking for home service businesses"
- "Trained on your real services, pricing, and FAQs"
- "Answers your website chat and text messages automatically"
- "Escalates emergencies to your team immediately"
- "Real-time dashboard of leads, response times, and booked revenue"

**Use with a caveat, or only in a "coming soon" context:**
- Any specific response-time number (e.g., "under 60 seconds") — the system is capable of this, but it hasn't been load-tested or measured in production yet
- "Automations" — fine to mention you can *create* rules, but don't imply they run automatically yet
- "Invite your team" — fine, but don't imply team members can log in and use the product yet

**Do not use:**
- "Integrates with ServiceTitan / Jobber / HubSpot / Zapier"
- "Syncs with your Google Calendar"
- "AI trained on your uploaded documents"
- "Secure role-based permissions for your team"
